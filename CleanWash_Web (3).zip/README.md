# CleanWash – Firemná web stránka

Vitajte na oficiálnej stránke firmy **CleanWash** – váš partner pre čistotu.

Tento projekt obsahuje jednoduchú statickú webovú stránku vytvorenú v HTML a Tailwind CSS. Slúži ako firemná prezentácia služieb vápkovania a čistenia.

---

## 🔧 Ako nasadiť stránku cez GitHub Pages

1. **Vytvor si nový repozitár na [GitHub](https://github.com)**
2. **Rozbaľ ZIP súbor a nahraj obsah** (napr. `index.html`) do koreňa repozitára
3. **Commitni zmeny** (tlačidlo „Commit changes“)
4. **Choď do záložky `Settings → Pages`**
   - Vyber Branch: `main`
   - Vyber folder: `/ (root)`
   - Klikni na „Save“
5. Po chvíli bude tvoja stránka dostupná napríklad na:
   ```
   https://tvoje-meno.github.io/cleanwash/
   ```

---

## 📄 Obsah projektu

- `index.html` – hlavná stránka

---

## 📞 Kontakt

- Email: matejmn0@gmail.com
- Telefón: 0915 122 478
